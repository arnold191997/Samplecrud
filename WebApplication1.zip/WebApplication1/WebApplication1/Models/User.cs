﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class User
    {
        public int id { get; set; }

        public string firstname { get; set; }

        public string lastname { get; set; }

        public string emailid { get; set; }

        public string mobilenumber { get; set; }
    }
}